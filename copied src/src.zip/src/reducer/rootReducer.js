import { combineReducers } from 'redux';
import skillReducer from './skillReducer';
export default combineReducers({
    skillReducer
});